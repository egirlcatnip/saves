for _, resource in pairs(data.raw.resource) do
  resource.map_grid = false
end
