data:extend({
    {
        type = "int-setting",
        name = "dirtpath-wear-threshhold",
        setting_type = "runtime-global",
        default_value = 14,
        order = "01"
    }
})