storage.dirt = {} --Technically a v1.1.1 migration
storage.flattening = nil