require("prototypes/light")
