data:extend{
    {
        type = "bool-setting",
        name = "tint-ghosts",
        setting_type = "startup",
        default_value = true,
        order = "i"
    },
    {
        type = "bool-setting",
        name = "wide-flashlight",
        setting_type = "startup",
        default_value = true,
        order = "j"
    },
    {
        type = "bool-setting",
        name = "enhanced-nightvision",
        setting_type = "startup",
        default_value = true,
        order = "k"
    },
    {
        type = "string-setting",
        name = "night-lut-set",
        setting_type = "startup",
        default_value = "Dark",
        allowed_values = {"Dark", "Bright"},
        order = "l"
    },
}
